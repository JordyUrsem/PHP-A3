var emptyButton = $(".emptyButton");
var button = $(".button");
var storedNumber;
var subIdArray = [];
var doneArray = [];

button.click(function(event) {
    alert('This card is already clicked please try another one')
});

emptyButton.click(function(event) {
    var id = $(this).attr('id');//
    var subId = id.substring(11);
    subIdArray.push(subId);
    var flippedButton = $("#button"+subId);

    $(this).hide();
    flippedButton.show();

    if (typeof storedNumber == 'undefined') {
        storedNumber = flippedButton.text();
    }

    else if (storedNumber !== flippedButton.text()) {
        subIdArray = [];
        storedNumber = undefined;

        setTimeout(function () {
            $(".button:not('.done')").hide();
            $(".emptyButton:not('.done')").show();
        }, 300);
    }

    else {
        doneArray.push(1,1);
        for (var i = 0; i < subIdArray.length; i++) {
            $("#button"+subIdArray[i]).css('background-color', 'green').addClass('done');
            $("#emptybutton"+subIdArray[i]).addClass('done');
        }
        subIdArray = [];
        storedNumber = undefined;
    }

    if (doneArray.length == 16) {
        alert('YOU DID IT!');

        setTimeout(function () {
            location.reload();
        }, 1000);
    }
});
