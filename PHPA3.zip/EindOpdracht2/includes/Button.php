<?php
class Button{
    private $randomNumber;
    private $id = 0;


    public function __construct($id, $buttons){
        $this->id = $id;
        $this->randomNumber = $buttons[$id];
    }

    public function render(){
        echo "<button class='button' hidden id=\"". "button".$this->id ."\">". $this->randomNumber ."</button>";

        echo "<button class='emptyButton' id=\"". "emptybutton".$this->id ."\"></button>";
    }
}
