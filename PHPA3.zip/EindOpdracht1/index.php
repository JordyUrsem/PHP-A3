
<?php
class House {
    protected $yearOfConstruction = "Niet ingevuld";
    protected $streetName = "Niet ingevuld";
    protected $houseNumber = "Niet ingevuld";
    protected $city = "Niet ingevuld";
    protected $amountOfRooms = "Niet ingevuld";
    protected $amountOfToilets = "Niet ingevuld";
    protected $heater = "Niet ingevuld";
    protected $heaterSort = "Niet ingevuld";
    protected $energyLabel = "Niet ingevuld";
    protected $squareMeters = "Niet ingevuld";
    protected $roofSort = "Niet ingevuld";
    protected $wozValue = "Niet ingevuld";
    protected $tax = "Niet ingevuld";
    public function __construct($streetName, $houseNumber, $city){
        $this->streetName = $streetName;
        $this->houseNumber = $houseNumber;
        $this->city = $city;
    }
    public function setYearOfConstuction($yearOfConstruction){
        $this->yearOfConstruction = $yearOfConstruction;
    }
    public function setAmountOfRooms($amountOfRooms){
        $this->amountOfRooms = $amountOfRooms;
    }
    public function setAmountOfToilets($amountOfToilets){
        $this->amountOfToilets = $amountOfToilets;
    }
    public function setHeater($heater){
        if ($heater == true || $heater == false) {
            if ($heater == true) {
                $heater = "Yes";
            } elseif ($heater == false) {
                $heater = "No";
            }
            $this->heater = $heater;
        } else {
            echo "Please set the heater value to true or false.";
        }
    }
    public function setHeaterSort($heaterSort){
        $answers = array("floorheating", "cv", "combo");
        if (in_array(strtolower($heaterSort), $answers)) {
            $this->heaterSort = $heaterSort;
            $this->setHeater(true);
        } else {
             echo ("ERROR: Please enter one of these values for the heater<br><br>
             <ul>
             <li>Floorheating</li>
             <li>CV</li>
             <li>Combo</li>
             </ul>");
        }
    }
    public function setEnergyLabel($energyLabel){
        $answers = array("a+++", "a++", "a+", "a", "b", "c", "d");
        if (in_array(strtolower($energyLabel), $answers)) {
            $this->energyLabel = strtoupper($energyLabel);
        } else {// ERROR
            echo "ERROR: Wrong label!<br>Please use one of the following values:<br><br>
            <ul>
            <li>D</li>
            <li>C</li>
            <li>B</li>
            <li>A</li>
            <li>A+</li>
            <li>A++</li>
            <li>A+++</li>
            </ul>";
        }
    }
    public function setSquareMeters($squareMeters){
        $this->squareMeters = $squareMeters . "m<sup>2</sub>";
    }
    public function setRoofSort($roofSort){
        $this->roofSort = $roofSort;
    }
    public function setWOZValue($wozValue){
        $this->wozValue = "€" . $wozValue . ",-";
        $this->setTaxesValue($wozValue);
    }
    private function setTaxesValue($tax){

        if ($this->wozValue <= 100000) {
            $tax += 600;
        } elseif ($this->wozValue <= 200000) {
            $tax += 2000;
        } elseif ($this->wozValue > 200000) {
            $tax =+ 6000;
        }


        if ($this->amountOfRooms == 1) {
            $tax += 100;
        } elseif ($this->amountOfRooms == 2) {
            $tax += 300;
        } elseif ($this->amountOfRooms > 2) {
            $tax += 800;
        }
        $answers = array("amsterdam" , "rotterdam", "groningen");
        if (in_array(strtolower($this->city), $answers)) {
            $tax += 1000;
        }

        $this->tax = "€" . $tax . ",-";
    }
    public function getProperties(){
        return  "Street name: " . $this->streetName . "<br>" .
                "House number: " . $this->houseNumber . "<br>" .
                "City: " . $this->city . "<br>" .
                "Amount of rooms: " . $this->amountOfRooms . "<br>" .
                "Amount of toilets: " . $this->amountOfToilets . "<br>" .
                "Heater: " . $this->heater . "<br>" .
                "Heater Sort: " . $this->heaterSort . "<br>" .
                "Energy Label:" . $this->energyLabel . "<br>" .
                "Square Meters: " . $this->squareMeters . "<br>" .
                "Roof Sort: " . $this->roofSort . "<br>" .
                "WoZ value: " . $this->wozValue . "<br>" .
                "Taxes: " . $this->tax . "<hr>";
    }
}
$house1 = new House("abc straat", 1234, "Amsterdam");
$house1->setAmountOfRooms(2);
$house1->setAmountOfToilets(1);
$house1->setHeater(true);
$house1->setHeaterSort("floorheating");
$house1->setEnergyLabel("A+++");
$house1->setSquareMeters(20);
$house1->setRoofSort("flat");
$house1->setWOZValue(90000);
echo $house1->getProperties();

$house2 = new House("nepstraat", 3211, "Emmen");
$house2->setAmountOfRooms(5);
$house2->setAmountOfToilets(2);
$house2->setHeater(true);
$house2->setHeaterSort("combo");
$house2->setEnergyLabel("D");
$house2->setSquareMeters(200);
$house2->setRoofSort("pointy");
$house2->setWOZValue(190000);
echo $house2->getProperties();


$house3 = new House("een straat", 1123, "Rotterdam");
$house3->setAmountOfRooms(2);
$house3->setAmountOfToilets(1);
$house3->setHeater(false);
$house3->setHeaterSort("cv");
$house3->setEnergyLabel("");
$house3->setSquareMeters(30);
$house3->setRoofSort("flat");
$house3->setWOZValue(120000);
echo $house3->getProperties();
